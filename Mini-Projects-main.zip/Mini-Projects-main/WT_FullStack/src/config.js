export const RECIPE_API = "https://forkify-api.herokuapp.com/api";
// export const RECIPE_API = "https://tasty.p.rapidapi.com/recipes/auto-complete";
